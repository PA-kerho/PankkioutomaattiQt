#ifndef SLSALDO2_H
#define SLSALDO2_H


#include "slsaldo2_global.h"
#include "saldodialog.h"

class SLSALDO2SHARED_EXPORT SLSaldo2
{

public:
    SLSaldo2();
    SaldoDialog SaldoDialogi;
};

#endif // SLSALDO_H
