#include "slsaldo2.h"


SLSaldo2::SLSaldo2()
{
}
