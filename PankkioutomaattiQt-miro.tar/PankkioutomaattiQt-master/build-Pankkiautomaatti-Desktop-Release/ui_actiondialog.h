/********************************************************************************
** Form generated from reading UI file 'actiondialog.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACTIONDIALOG_H
#define UI_ACTIONDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ActionDialog
{
public:
    QPushButton *pushButtonNosto;
    QPushButton *pushButtonClose;
    QPushButton *pushButtonELasku;
    QPushButton *pushButtonSaldo;
    QPushButton *pushButtonSiirto;

    void setupUi(QDialog *ActionDialog)
    {
        if (ActionDialog->objectName().isEmpty())
            ActionDialog->setObjectName(QStringLiteral("ActionDialog"));
        ActionDialog->resize(1413, 885);
        ActionDialog->setStyleSheet(QLatin1String("width: 100%;\n"
"height: 100%;\n"
"background-color: #0F2A45;\n"
""));
        pushButtonNosto = new QPushButton(ActionDialog);
        pushButtonNosto->setObjectName(QStringLiteral("pushButtonNosto"));
        pushButtonNosto->setGeometry(QRect(750, 430, 171, 151));
        pushButtonNosto->setStyleSheet(QLatin1String("font-size: 40px;\n"
"background-color: white;"));
        pushButtonClose = new QPushButton(ActionDialog);
        pushButtonClose->setObjectName(QStringLiteral("pushButtonClose"));
        pushButtonClose->setGeometry(QRect(990, 620, 171, 151));
        pushButtonClose->setStyleSheet(QLatin1String("font-size: 40px;\n"
"background-color: white;"));
        pushButtonELasku = new QPushButton(ActionDialog);
        pushButtonELasku->setObjectName(QStringLiteral("pushButtonELasku"));
        pushButtonELasku->setGeometry(QRect(750, 620, 171, 151));
        pushButtonELasku->setStyleSheet(QLatin1String("font-size: 40px;\n"
"background-color: white;"));
        pushButtonSaldo = new QPushButton(ActionDialog);
        pushButtonSaldo->setObjectName(QStringLiteral("pushButtonSaldo"));
        pushButtonSaldo->setGeometry(QRect(990, 430, 171, 151));
        pushButtonSaldo->setStyleSheet(QLatin1String("font-size: 40px;\n"
"background-color: white;"));
        pushButtonSiirto = new QPushButton(ActionDialog);
        pushButtonSiirto->setObjectName(QStringLiteral("pushButtonSiirto"));
        pushButtonSiirto->setGeometry(QRect(750, 240, 411, 151));
        pushButtonSiirto->setStyleSheet(QLatin1String("font-size: 40px;\n"
"background-color: rgb(255, 255, 255);\n"
""));

        retranslateUi(ActionDialog);

        QMetaObject::connectSlotsByName(ActionDialog);
    } // setupUi

    void retranslateUi(QDialog *ActionDialog)
    {
        ActionDialog->setWindowTitle(QApplication::translate("ActionDialog", "Dialog", 0));
        pushButtonNosto->setText(QApplication::translate("ActionDialog", "Nosto", 0));
        pushButtonClose->setText(QApplication::translate("ActionDialog", "Sulje", 0));
        pushButtonELasku->setText(QApplication::translate("ActionDialog", "E-laskut", 0));
        pushButtonSaldo->setText(QApplication::translate("ActionDialog", "Saldo", 0));
        pushButtonSiirto->setText(QApplication::translate("ActionDialog", "Siirto omalle tilille", 0));
    } // retranslateUi

};

namespace Ui {
    class ActionDialog: public Ui_ActionDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACTIONDIALOG_H
