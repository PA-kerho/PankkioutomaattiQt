/********************************************************************************
** Form generated from reading UI file 'siirtodialog.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SIIRTODIALOG_H
#define UI_SIIRTODIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_SiirtoDialog
{
public:
    QComboBox *comboBoxTililta;
    QLabel *label;
    QComboBox *comboBoxTilille;
    QPushButton *pushButtonDel;
    QPushButton *pushButton2;
    QPushButton *pushButtonCancel;
    QPushButton *pushButtonHyvaksy;
    QPushButton *pushButton8;
    QPushButton *pushButton9;
    QPushButton *pushButton5;
    QPushButton *pushButton1;
    QPushButton *pushButton4;
    QPushButton *pushButton6;
    QPushButton *pushButton0;
    QPushButton *pushButton3;
    QPushButton *pushButton7;
    QLineEdit *lineEditSumma;
    QPushButton *pushButtonPiste;
    QLabel *label_2;
    QLabel *label_3;

    void setupUi(QDialog *SiirtoDialog)
    {
        if (SiirtoDialog->objectName().isEmpty())
            SiirtoDialog->setObjectName(QStringLiteral("SiirtoDialog"));
        SiirtoDialog->resize(800, 640);
        SiirtoDialog->setStyleSheet(QLatin1String("\n"
"	background: #0F2A45;\n"
""));
        comboBoxTililta = new QComboBox(SiirtoDialog);
        comboBoxTililta->setObjectName(QStringLiteral("comboBoxTililta"));
        comboBoxTililta->setGeometry(QRect(150, 150, 251, 41));
        comboBoxTililta->setStyleSheet(QLatin1String("\n"
"background-color: white;\n"
"selection-background-color: rgb(161, 170, 215);"));
        label = new QLabel(SiirtoDialog);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(230, 0, 371, 91));
        label->setStyleSheet(QLatin1String("font: 25 32pt \"Roboto\";\n"
"font: 25 56pt \"Roboto\";\n"
"color:white;\n"
""));
        comboBoxTilille = new QComboBox(SiirtoDialog);
        comboBoxTilille->setObjectName(QStringLiteral("comboBoxTilille"));
        comboBoxTilille->setGeometry(QRect(150, 260, 251, 41));
        comboBoxTilille->setStyleSheet(QLatin1String("background-color: white;\n"
"selection-background-color: rgb(161, 170, 215);"));
        pushButtonDel = new QPushButton(SiirtoDialog);
        pushButtonDel->setObjectName(QStringLiteral("pushButtonDel"));
        pushButtonDel->setGeometry(QRect(410, 410, 81, 71));
        QFont font;
        font.setPointSize(18);
        pushButtonDel->setFont(font);
        pushButtonDel->setStyleSheet(QStringLiteral("background: white;"));
        pushButton2 = new QPushButton(SiirtoDialog);
        pushButton2->setObjectName(QStringLiteral("pushButton2"));
        pushButton2->setGeometry(QRect(510, 150, 81, 71));
        pushButton2->setFont(font);
        pushButton2->setStyleSheet(QStringLiteral("background: white;"));
        pushButtonCancel = new QPushButton(SiirtoDialog);
        pushButtonCancel->setObjectName(QStringLiteral("pushButtonCancel"));
        pushButtonCancel->setGeometry(QRect(150, 500, 241, 91));
        pushButtonCancel->setFont(font);
        pushButtonCancel->setStyleSheet(QStringLiteral("background: white;"));
        pushButtonHyvaksy = new QPushButton(SiirtoDialog);
        pushButtonHyvaksy->setObjectName(QStringLiteral("pushButtonHyvaksy"));
        pushButtonHyvaksy->setGeometry(QRect(150, 410, 241, 71));
        pushButtonHyvaksy->setFont(font);
        pushButtonHyvaksy->setStyleSheet(QStringLiteral("background: white;"));
        pushButton8 = new QPushButton(SiirtoDialog);
        pushButton8->setObjectName(QStringLiteral("pushButton8"));
        pushButton8->setGeometry(QRect(510, 320, 81, 71));
        pushButton8->setFont(font);
        pushButton8->setStyleSheet(QStringLiteral("background: white;"));
        pushButton9 = new QPushButton(SiirtoDialog);
        pushButton9->setObjectName(QStringLiteral("pushButton9"));
        pushButton9->setGeometry(QRect(610, 320, 81, 71));
        pushButton9->setFont(font);
        pushButton9->setStyleSheet(QStringLiteral("background: white;"));
        pushButton5 = new QPushButton(SiirtoDialog);
        pushButton5->setObjectName(QStringLiteral("pushButton5"));
        pushButton5->setGeometry(QRect(510, 230, 81, 71));
        pushButton5->setFont(font);
        pushButton5->setStyleSheet(QStringLiteral("background: white;"));
        pushButton1 = new QPushButton(SiirtoDialog);
        pushButton1->setObjectName(QStringLiteral("pushButton1"));
        pushButton1->setGeometry(QRect(410, 150, 81, 71));
        pushButton1->setFont(font);
        pushButton1->setStyleSheet(QStringLiteral("background: white;"));
        pushButton4 = new QPushButton(SiirtoDialog);
        pushButton4->setObjectName(QStringLiteral("pushButton4"));
        pushButton4->setGeometry(QRect(410, 230, 81, 71));
        pushButton4->setFont(font);
        pushButton4->setStyleSheet(QStringLiteral("background: white;"));
        pushButton6 = new QPushButton(SiirtoDialog);
        pushButton6->setObjectName(QStringLiteral("pushButton6"));
        pushButton6->setGeometry(QRect(610, 230, 81, 71));
        pushButton6->setFont(font);
        pushButton6->setStyleSheet(QStringLiteral("background: white;"));
        pushButton0 = new QPushButton(SiirtoDialog);
        pushButton0->setObjectName(QStringLiteral("pushButton0"));
        pushButton0->setGeometry(QRect(510, 410, 81, 71));
        pushButton0->setFont(font);
        pushButton0->setStyleSheet(QStringLiteral("background: white;"));
        pushButton3 = new QPushButton(SiirtoDialog);
        pushButton3->setObjectName(QStringLiteral("pushButton3"));
        pushButton3->setGeometry(QRect(610, 150, 81, 71));
        pushButton3->setFont(font);
        pushButton3->setStyleSheet(QStringLiteral("background: white;"));
        pushButton7 = new QPushButton(SiirtoDialog);
        pushButton7->setObjectName(QStringLiteral("pushButton7"));
        pushButton7->setGeometry(QRect(410, 320, 81, 71));
        pushButton7->setFont(font);
        pushButton7->setStyleSheet(QStringLiteral("background: white;"));
        lineEditSumma = new QLineEdit(SiirtoDialog);
        lineEditSumma->setObjectName(QStringLiteral("lineEditSumma"));
        lineEditSumma->setGeometry(QRect(410, 500, 281, 91));
        QFont font1;
        font1.setPointSize(30);
        font1.setBold(false);
        font1.setUnderline(false);
        font1.setWeight(50);
        lineEditSumma->setFont(font1);
        lineEditSumma->setStyleSheet(QStringLiteral("background: white;"));
        lineEditSumma->setEchoMode(QLineEdit::Normal);
        lineEditSumma->setClearButtonEnabled(false);
        pushButtonPiste = new QPushButton(SiirtoDialog);
        pushButtonPiste->setObjectName(QStringLiteral("pushButtonPiste"));
        pushButtonPiste->setGeometry(QRect(610, 410, 81, 71));
        pushButtonPiste->setFont(font);
        pushButtonPiste->setStyleSheet(QStringLiteral("background: white;"));
        label_2 = new QLabel(SiirtoDialog);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(150, 120, 121, 21));
        label_2->setStyleSheet(QLatin1String("font: 25 20pt \"Roboto\";\n"
"color:white;"));
        label_3 = new QLabel(SiirtoDialog);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(150, 230, 151, 21));
        label_3->setStyleSheet(QLatin1String("font: 25 20pt \"Roboto\";\n"
"color:white;"));

        retranslateUi(SiirtoDialog);

        QMetaObject::connectSlotsByName(SiirtoDialog);
    } // setupUi

    void retranslateUi(QDialog *SiirtoDialog)
    {
        SiirtoDialog->setWindowTitle(QApplication::translate("SiirtoDialog", "Dialog", 0));
        label->setText(QApplication::translate("SiirtoDialog", "TILISIIRTO", 0));
        pushButtonDel->setText(QApplication::translate("SiirtoDialog", "DEL", 0));
        pushButton2->setText(QApplication::translate("SiirtoDialog", "2", 0));
        pushButtonCancel->setText(QApplication::translate("SiirtoDialog", "CANCEL", 0));
        pushButtonHyvaksy->setText(QApplication::translate("SiirtoDialog", "HYV\303\204KSY", 0));
        pushButton8->setText(QApplication::translate("SiirtoDialog", "8", 0));
        pushButton9->setText(QApplication::translate("SiirtoDialog", "9", 0));
        pushButton5->setText(QApplication::translate("SiirtoDialog", "5", 0));
        pushButton1->setText(QApplication::translate("SiirtoDialog", "1", 0));
        pushButton4->setText(QApplication::translate("SiirtoDialog", "4", 0));
        pushButton6->setText(QApplication::translate("SiirtoDialog", "6", 0));
        pushButton0->setText(QApplication::translate("SiirtoDialog", "0", 0));
        pushButton3->setText(QApplication::translate("SiirtoDialog", "3", 0));
        pushButton7->setText(QApplication::translate("SiirtoDialog", "7", 0));
        lineEditSumma->setInputMask(QString());
        lineEditSumma->setPlaceholderText(QApplication::translate("SiirtoDialog", "     Summa \342\202\254", 0));
        pushButtonPiste->setText(QApplication::translate("SiirtoDialog", ".", 0));
        label_2->setText(QApplication::translate("SiirtoDialog", "Tililt\303\244:", 0));
        label_3->setText(QApplication::translate("SiirtoDialog", "Tilille:", 0));
    } // retranslateUi

};

namespace Ui {
    class SiirtoDialog: public Ui_SiirtoDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SIIRTODIALOG_H
