/********************************************************************************
** Form generated from reading UI file 'saldodialog.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SALDODIALOG_H
#define UI_SALDODIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_SaldoDialog
{
public:
    QLabel *labelSaldo;
    QLabel *labelTiliNimi;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QDialog *SaldoDialog)
    {
        if (SaldoDialog->objectName().isEmpty())
            SaldoDialog->setObjectName(QStringLiteral("SaldoDialog"));
        SaldoDialog->resize(1294, 780);
        SaldoDialog->setStyleSheet(QStringLiteral("background-color: #0F2A45;"));
        labelSaldo = new QLabel(SaldoDialog);
        labelSaldo->setObjectName(QStringLiteral("labelSaldo"));
        labelSaldo->setGeometry(QRect(770, 110, 181, 61));
        labelSaldo->setStyleSheet(QStringLiteral(""));
        labelTiliNimi = new QLabel(SaldoDialog);
        labelTiliNimi->setObjectName(QStringLiteral("labelTiliNimi"));
        labelTiliNimi->setGeometry(QRect(280, 110, 181, 61));
        labelTiliNimi->setStyleSheet(QStringLiteral(""));
        label = new QLabel(SaldoDialog);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(580, 290, 68, 21));
        label_2 = new QLabel(SaldoDialog);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(340, 480, 551, 21));

        retranslateUi(SaldoDialog);

        QMetaObject::connectSlotsByName(SaldoDialog);
    } // setupUi

    void retranslateUi(QDialog *SaldoDialog)
    {
        SaldoDialog->setWindowTitle(QApplication::translate("SaldoDialog", "Dialog", 0));
        labelSaldo->setText(QString());
        labelTiliNimi->setText(QString());
        label->setText(QApplication::translate("SaldoDialog", "TextLabel", 0));
        label_2->setText(QApplication::translate("SaldoDialog", "TextLabel", 0));
    } // retranslateUi

};

namespace Ui {
    class SaldoDialog: public Ui_SaldoDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SALDODIALOG_H
