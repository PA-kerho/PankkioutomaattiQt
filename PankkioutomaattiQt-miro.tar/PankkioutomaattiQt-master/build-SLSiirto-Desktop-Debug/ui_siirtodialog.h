/********************************************************************************
** Form generated from reading UI file 'siirtodialog.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SIIRTODIALOG_H
#define UI_SIIRTODIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_SiirtoDialog
{
public:
    QComboBox *comboBoxTililta;
    QLabel *label;
    QLabel *label_2;
    QComboBox *comboBoxTilille;
    QPushButton *pushButtonOk;
    QPushButton *pushButtonCanc;

    void setupUi(QDialog *SiirtoDialog)
    {
        if (SiirtoDialog->objectName().isEmpty())
            SiirtoDialog->setObjectName(QStringLiteral("SiirtoDialog"));
        SiirtoDialog->resize(1326, 813);
        SiirtoDialog->setStyleSheet(QLatin1String("\n"
"	background: #0F2A45;\n"
""));
        comboBoxTililta = new QComboBox(SiirtoDialog);
        comboBoxTililta->setObjectName(QStringLiteral("comboBoxTililta"));
        comboBoxTililta->setGeometry(QRect(550, 220, 85, 31));
        label = new QLabel(SiirtoDialog);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(257, 220, 261, 21));
        label->setStyleSheet(QStringLiteral("color:white;"));
        label_2 = new QLabel(SiirtoDialog);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(260, 310, 261, 21));
        label_2->setStyleSheet(QStringLiteral("color:white;"));
        comboBoxTilille = new QComboBox(SiirtoDialog);
        comboBoxTilille->setObjectName(QStringLiteral("comboBoxTilille"));
        comboBoxTilille->setGeometry(QRect(550, 310, 85, 31));
        pushButtonOk = new QPushButton(SiirtoDialog);
        pushButtonOk->setObjectName(QStringLiteral("pushButtonOk"));
        pushButtonOk->setGeometry(QRect(490, 410, 101, 31));
        pushButtonCanc = new QPushButton(SiirtoDialog);
        pushButtonCanc->setObjectName(QStringLiteral("pushButtonCanc"));
        pushButtonCanc->setGeometry(QRect(620, 410, 101, 31));

        retranslateUi(SiirtoDialog);

        QMetaObject::connectSlotsByName(SiirtoDialog);
    } // setupUi

    void retranslateUi(QDialog *SiirtoDialog)
    {
        SiirtoDialog->setWindowTitle(QApplication::translate("SiirtoDialog", "Dialog", 0));
        label->setText(QApplication::translate("SiirtoDialog", "TextLabel", 0));
        label_2->setText(QApplication::translate("SiirtoDialog", "TextLabel", 0));
        pushButtonOk->setText(QApplication::translate("SiirtoDialog", "PushButton", 0));
        pushButtonCanc->setText(QApplication::translate("SiirtoDialog", "PushButton", 0));
    } // retranslateUi

};

namespace Ui {
    class SiirtoDialog: public Ui_SiirtoDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SIIRTODIALOG_H
