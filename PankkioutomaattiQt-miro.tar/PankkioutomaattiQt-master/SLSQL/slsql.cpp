#include "slsql.h"


SLSQL::SLSQL()
{
}


/*********CHECKCARD******/

bool SLSQL::Connect()
{
   db = QSqlDatabase::addDatabase("QMYSQL","db");
   db.setHostName("193.167.100.162");
   db.setDatabaseName("opisk_t4etni00");
   db.setUserName("t4etni00");
   db.setPassword("NPGW4p6X6t57nkgb");
   if(db.open())
   {
       QSqlQuery Query(db);
       query = Query;
       return true;
   }

    qDebug()<<"db: " << db.lastError();
    return false;

}




void SLSQL::DisConnect()
{
   db.close();
}

QString SLSQL::GetCard(QString CardID)
{
    query.prepare("SELECT PinKoodi FROM Kortit WHERE KortinNumero = :CardID");
    query.bindValue(":CardID", CardID); //Syötetään kyselyyn kortin id
    query.exec();
    if(query.size() > 0){
        query.first();
        return query.value(0).toString(); //Palautetaan rivin ensimmäinen alkio, joka sisältää pinkoodin
    }
    //Jos tänne päästään, ei tietokannasta löytynyt korttia
    qDebug()<<query.lastError();
    return "false";
}

/*

/*********CHECKCARD*****


/*********ELASKU******/
/*
QString SLSQL::GetBills(QString CardID)
{

    int i=0;
    query.prepare("SELECT E.ID, E.Saaja, E.AsiakasID, E.SaajanTilinro, E.Summa, E.Viitenumero, E.Viesti, E.Erapaiva, T.IBAN, T.TilinNimi, E.Tililta                                                  \
                  FROM (((Kortit as K                                          \
                  INNER JOIN KorttiTili as KT ON KT.KorttiID = K.ID)           \
                  INNER JOIN AsiakasTili as A ON A.TiliID = KT.TiliID)         \
                  INNER JOIN ELasku as E ON E.AsiakasID = A.AsiakasID)         \
                  INNER JOIN Tilit as T ON E.Tililta = T.ID                    \
                  WHERE K.KortinNumero = :CardID AND E.Maksettu = 0 AND E.Hyvaksytty = 0");

    query.bindValue(":CardID", CardID);
    query.exec();
    if(query.size() > 0)
    {
        while(query.next())
        {
            eLaskut[i][0] = query.value(0).toString();
            eLaskut[i][1] = query.value(1).toString();
            eLaskut[i][2] = query.value(2).toString();
            eLaskut[i][3] = query.value(3).toString();
            eLaskut[i][4] = query.value(4).toString();
            eLaskut[i][5] = query.value(5).toString();
            eLaskut[i][6] = query.value(6).toString();
            eLaskut[i][7] = query.value(7).toString();
            eLaskut[i][8] = query.value(8).toString();
            eLaskut[i][9] = query.value(9).toString();
            eLaskut[i][10] = query.value(10).toString();
            i++;
        }
    }
    else
    {
     eLaskut[0][0]="False";
     eLaskut[0][1]="Ei hyväksymättömiä laskuja";
     i++;
    }

    for(int k = i; k < 100-i; k++){
        for(int j = 0; j < 11; j++){
           eLaskut[k][j] = "";
        }
    }
    return eLaskut[100][11];
}

bool SLSQL::GetSaldo(int Summa, QString CardID)
{
    bool a,b,c;
    query.prepare("SELECT SUM(TuloMeno), T.TiliID FROM (Kortit as K\
                  INNER JOIN KorttiTili as KT ON KT.KorttiID=K.ID)\
                  INNER JOIN Tilitapahtumat as T ON T.TiliID = KT.TiliID\
                  WHERE K.KortinNumero = :CardID");
    query.bindValue(":CardID", CardID); //Syötetään kyselyyn kortin id
    query.exec(); // Suoritetaan kysely
    if(query.size() > 0)
    { // Jos kysely palauttaa rivin
        query.first(); //Valitaan esimmäinen rivi
        int Saldo = query.value(0).toInt(); //Muutetaan rivin ensimmäisen alkion arvo kokonaisluvuksi ja tallennetaan Saldo-muuttujaan
        if(Saldo >= Summa)
        { //Jos Saldo on suurempi kuin Summa, eli kate tilillä riittää
            int TiliID = query.value(1).toInt(); //Tallennetaan TiliID-muuttujaan rivin toinen alkio muutettuna kokonasluvuksi
                    /*** Lisätään tietokantaan tilitapahtuma **
            query.prepare("INSERT INTO Tilitapahtumat (Aika, TapahtumanTyyppi, TuloMeno, TiliID) VALUES(NOW(),'Käteisnosto', :Summa, :TiliID)");
            query.bindValue(":Summa", (0-Summa)); //Syötetään kyselyyn summa negatiivisenä
            query.bindValue(":TiliID", TiliID);
            if(query.exec())
            {
                a=true;
                b=false;
                c=false;
            }
            else
            {
                a=false;
                b=false;
                c=false;
            }


        }
        else
        {
            if(Saldo < Summa)
            {
                a=false;
                b=true;
                c=false;
            }
        }

    }
    else
    {
        a=false;
        b=false;
        c=true;
    }
    return a;
    return b;
    return c;

}


bool SLSQL::CheckSaldo(QString IBANs[100][3],int IDs[100], int k, int Loops)
{
    query.prepare("SELECT SUM(TuloMeno) FROM Tilitapahtumat as TT LEFT JOIN Tilit as T ON T.ID = TT.TiliID WHERE T.IBAN = :IBAN");
    for(int i = 0; i < k; i++){
        float Sum = 0.0;
        query.bindValue(":IBAN", IBANs[i][0]);
        query.exec();
        if(query.size() > 0){
            query.first();
            Sum = query.value(0).toFloat();
        }
        if(Sum < IBANs[i][2].toFloat()){ //Muutetaan IBANs-taulukossa oleva summa liukuluvuksi, ja tarkistetaan, onko se suurempi kuin tietokannasta haettu summa
            return false; //Jos on, tilin kate ei riitä, ja palautetaan funktiosta false.
        }
    }

    for(int i = 0; i < k; i++){
        query.prepare("UPDATE ELasku SET Maksettu = 1, Hyvaksytty = 1, MaksuAika = NOW() WHERE ID IN("+IBANs[i][1]+")");
        query.exec();
    }

    query.prepare("INSERT INTO Tilitapahtumat (Aika, TapahtumanTyyppi, TuloMeno, TiliID, Saaja, SaajanTilinro, Viitenumero) \
                   VALUES(NOW(), 'eLasku', :Summa, :TiliID, :Saaja, :SaajanTilinro, :Viitenumero)");
    for(int i = 0; i < Loops; i++){
        query.bindValue(":Summa", 0-((eLaskut[IDs[i]][4]).toFloat()));
        query.bindValue(":TiliID", (eLaskut[IDs[i]][10]).toInt());
        query.bindValue(":Saaja", eLaskut[IDs[i]][1]);
        query.bindValue(":SaajanTilinro", eLaskut[IDs[i]][3]);
        query.bindValue(":Viitenumero", eLaskut[IDs[i]][5]);
        query.exec();
    }
    return true;
}



bool SLSQL::Lukitse(QString CardID)
{
    query.prepare("UPDATE Kortit SET Lukittu=1 WHERE ID=:CardID");
    if(query.exec())
    {
        return true;
    }
    else
    {
        return false;
    }
}
*/
