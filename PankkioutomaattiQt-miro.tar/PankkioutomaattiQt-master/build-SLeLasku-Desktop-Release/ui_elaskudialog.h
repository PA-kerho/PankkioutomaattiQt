/********************************************************************************
** Form generated from reading UI file 'elaskudialog.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ELASKUDIALOG_H
#define UI_ELASKUDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_eLaskuDialog
{
public:
    QLabel *label;
    QPushButton *pushButtonPeruuta;
    QListWidget *listWidget;
    QPushButton *pushButtonHyvaksy;
    QPushButton *pushButtonMaksaNyt;

    void setupUi(QDialog *eLaskuDialog)
    {
        if (eLaskuDialog->objectName().isEmpty())
            eLaskuDialog->setObjectName(QStringLiteral("eLaskuDialog"));
        eLaskuDialog->resize(1569, 1249);
        eLaskuDialog->setStyleSheet(QLatin1String("QWidget{\n"
"	width: 100%;\n"
"	height: 100%;\n"
"	background-color: #0F2A45;\n"
"}\n"
"QListWidget::item:active{\n"
"	background: #0F2A45;\n"
"}"));
        label = new QLabel(eLaskuDialog);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(720, 40, 211, 51));
        label->setStyleSheet(QLatin1String("font-size: 50px;\n"
"color: white;"));
        pushButtonPeruuta = new QPushButton(eLaskuDialog);
        pushButtonPeruuta->setObjectName(QStringLiteral("pushButtonPeruuta"));
        pushButtonPeruuta->setGeometry(QRect(50, 620, 171, 161));
        pushButtonPeruuta->setStyleSheet(QLatin1String("font-size: 40px;\n"
"background-color:white;"));
        listWidget = new QListWidget(eLaskuDialog);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(260, 180, 1031, 651));
        listWidget->setStyleSheet(QLatin1String("color: white;\n"
"font-size: 25px;\n"
"border:0;\n"
""));
        pushButtonHyvaksy = new QPushButton(eLaskuDialog);
        pushButtonHyvaksy->setObjectName(QStringLiteral("pushButtonHyvaksy"));
        pushButtonHyvaksy->setGeometry(QRect(1410, 680, 171, 161));
        pushButtonHyvaksy->setStyleSheet(QLatin1String("font-size: 40px;\n"
"background-color:white;"));
        pushButtonMaksaNyt = new QPushButton(eLaskuDialog);
        pushButtonMaksaNyt->setObjectName(QStringLiteral("pushButtonMaksaNyt"));
        pushButtonMaksaNyt->setGeometry(QRect(1410, 420, 171, 161));
        pushButtonMaksaNyt->setStyleSheet(QLatin1String("font-size: 36px;\n"
"background-color:white;"));

        retranslateUi(eLaskuDialog);

        QMetaObject::connectSlotsByName(eLaskuDialog);
    } // setupUi

    void retranslateUi(QDialog *eLaskuDialog)
    {
        eLaskuDialog->setWindowTitle(QApplication::translate("eLaskuDialog", "Dialog", 0));
        label->setText(QApplication::translate("eLaskuDialog", "E-Laskut", 0));
        pushButtonPeruuta->setText(QApplication::translate("eLaskuDialog", "Peruuta", 0));
        pushButtonHyvaksy->setText(QApplication::translate("eLaskuDialog", "Hyv\303\244ksy", 0));
        pushButtonMaksaNyt->setText(QApplication::translate("eLaskuDialog", "Maksa nyt", 0));
    } // retranslateUi

};

namespace Ui {
    class eLaskuDialog: public Ui_eLaskuDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ELASKUDIALOG_H
