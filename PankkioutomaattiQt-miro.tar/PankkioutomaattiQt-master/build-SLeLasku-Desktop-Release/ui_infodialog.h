/********************************************************************************
** Form generated from reading UI file 'infodialog.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INFODIALOG_H
#define UI_INFODIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_InfoDialog
{
public:
    QLabel *label;

    void setupUi(QDialog *InfoDialog)
    {
        if (InfoDialog->objectName().isEmpty())
            InfoDialog->setObjectName(QStringLiteral("InfoDialog"));
        InfoDialog->resize(1582, 919);
        InfoDialog->setStyleSheet(QLatin1String("QWidget{\n"
"	width: 100%;\n"
"	height: 100%;\n"
"	background-color: #0F2A45;\n"
"}\n"
"\n"
""));
        label = new QLabel(InfoDialog);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(400, 410, 851, 151));
        label->setStyleSheet(QLatin1String("font-size: 50px;\n"
"color: white;\n"
""));

        retranslateUi(InfoDialog);

        QMetaObject::connectSlotsByName(InfoDialog);
    } // setupUi

    void retranslateUi(QDialog *InfoDialog)
    {
        InfoDialog->setWindowTitle(QApplication::translate("InfoDialog", "Dialog", 0));
        label->setText(QApplication::translate("InfoDialog", "Infoikkuna", 0));
    } // retranslateUi

};

namespace Ui {
    class InfoDialog: public Ui_InfoDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INFODIALOG_H
