#ifndef SLSALDO_H
#define SLSALDO_H


#include "slsaldo_global.h"
#include "saldodialog.h"

class SLSALDOSHARED_EXPORT SLSaldo
{

public:
    SLSaldo();
    SaldoDialog SaldoDialogi;
};

#endif // SLSALDO_H
