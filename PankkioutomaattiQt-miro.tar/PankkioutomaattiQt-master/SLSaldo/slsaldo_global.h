#ifndef SLSALDO_GLOBAL_H
#define SLSALDO_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(SLSALDO_LIBRARY)
#  define SLSALDOSHARED_EXPORT Q_DECL_EXPORT
#else
#  define SLSALDOSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // SLSALDO_GLOBAL_H
