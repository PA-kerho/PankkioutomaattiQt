#ifndef SALDODIALOG_H
#define SALDODIALOG_H

#include <QDialog>
#include <QString>
#include <QSqlQuery>
#include <QDebug>

namespace Ui {
class SaldoDialog;
}

class SaldoDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SaldoDialog(QWidget *parent = 0);
    ~SaldoDialog();
    QString CardID;
    QSqlQuery query;
    QString saldo;
    void ShowSaldo();

private:
    Ui::SaldoDialog *ui;

};

#endif // SALDODIALOG_H
