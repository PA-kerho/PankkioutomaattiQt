#include "saldodialog.h"
#include "ui_saldodialog.h"

SaldoDialog::SaldoDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SaldoDialog)
{
    ui->setupUi(this);
    ShowSaldo();
    //ui->labelSaldo->setText(saldo);
}

SaldoDialog::~SaldoDialog()
{
    delete ui;
}

void SaldoDialog::ShowSaldo()
{
    /*query.prepare("SELECT SUM(TuloMeno) FROM Kortit AS K\
                  JOIN KorttiTili AS KT ON KT.KorttiID=K.ID\
                  JOIN Tilit as T ON T.ID=KT.TiliID\
                  JOIN Tilitapahtumat as TT ON TT.TiliID=KT.TiliID\
                  WHERE K.KortinNumero=:CardID");
    query.bindValue(":CardID", CardID); //Syötetään kyselyyn kortin id*/
    query.prepare("SELECT Sukunimi FROM Asiakas WHERE ID='14'");
    qDebug()
    query.exec();
    query.first();
    qDebug()<<query.value(0).toString();
    ui->labelSaldo->setText(saldo);




}

