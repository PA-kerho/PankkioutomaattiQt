#include "slnosto.h"


SLNosto::SLNosto(){
    /*******Turha luokka*******/
}
