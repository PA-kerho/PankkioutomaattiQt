#ifndef SLELASKU_H
#define SLELASKU_H

#include "slelasku_global.h"

class SLELASKUSHARED_EXPORT SLELasku
{

public:
    SLELasku();
};

#endif // SLELASKU_H
