#include "slelasku.h"


SLELasku::SLELasku()
{
}
