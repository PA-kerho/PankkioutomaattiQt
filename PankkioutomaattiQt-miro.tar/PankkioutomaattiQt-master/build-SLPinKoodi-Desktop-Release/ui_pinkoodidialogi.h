/********************************************************************************
** Form generated from reading UI file 'pinkoodidialogi.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PINKOODIDIALOGI_H
#define UI_PINKOODIDIALOGI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_PinkoodiDialogi
{
public:
    QPushButton *pushButton1;
    QPushButton *pushButton2;
    QPushButton *pushButton3;
    QPushButton *pushButton4;
    QPushButton *pushButton5;
    QPushButton *pushButton6;
    QPushButton *pushButton7;
    QPushButton *pushButton8;
    QPushButton *pushButton9;
    QPushButton *pushButton0;
    QPushButton *pushButtonDel;
    QPushButton *pushButtonLogin;
    QLineEdit *lineEditPIN;
    QLabel *labelLogin;
    QPushButton *pushButtonCancel;

    void setupUi(QDialog *PinkoodiDialogi)
    {
        if (PinkoodiDialogi->objectName().isEmpty())
            PinkoodiDialogi->setObjectName(QStringLiteral("PinkoodiDialogi"));
        PinkoodiDialogi->resize(1305, 932);
        PinkoodiDialogi->setStyleSheet(QLatin1String("width: 100%;\n"
"height: 100%;\n"
"background-color: #0F2A45;"));
        PinkoodiDialogi->setSizeGripEnabled(false);
        PinkoodiDialogi->setModal(false);
        pushButton1 = new QPushButton(PinkoodiDialogi);
        pushButton1->setObjectName(QStringLiteral("pushButton1"));
        pushButton1->setGeometry(QRect(820, 300, 81, 71));
        QFont font;
        font.setPointSize(18);
        pushButton1->setFont(font);
        pushButton1->setStyleSheet(QStringLiteral("background: white;"));
        pushButton2 = new QPushButton(PinkoodiDialogi);
        pushButton2->setObjectName(QStringLiteral("pushButton2"));
        pushButton2->setGeometry(QRect(920, 300, 81, 71));
        pushButton2->setFont(font);
        pushButton2->setStyleSheet(QStringLiteral("background: white;"));
        pushButton3 = new QPushButton(PinkoodiDialogi);
        pushButton3->setObjectName(QStringLiteral("pushButton3"));
        pushButton3->setGeometry(QRect(1020, 300, 81, 71));
        pushButton3->setFont(font);
        pushButton3->setStyleSheet(QStringLiteral("background: white;"));
        pushButton4 = new QPushButton(PinkoodiDialogi);
        pushButton4->setObjectName(QStringLiteral("pushButton4"));
        pushButton4->setGeometry(QRect(820, 380, 81, 71));
        pushButton4->setFont(font);
        pushButton4->setStyleSheet(QStringLiteral("background: white;"));
        pushButton5 = new QPushButton(PinkoodiDialogi);
        pushButton5->setObjectName(QStringLiteral("pushButton5"));
        pushButton5->setGeometry(QRect(920, 380, 81, 71));
        pushButton5->setFont(font);
        pushButton5->setStyleSheet(QStringLiteral("background: white;"));
        pushButton6 = new QPushButton(PinkoodiDialogi);
        pushButton6->setObjectName(QStringLiteral("pushButton6"));
        pushButton6->setGeometry(QRect(1020, 380, 81, 71));
        pushButton6->setFont(font);
        pushButton6->setStyleSheet(QStringLiteral("background: white;"));
        pushButton7 = new QPushButton(PinkoodiDialogi);
        pushButton7->setObjectName(QStringLiteral("pushButton7"));
        pushButton7->setGeometry(QRect(820, 470, 81, 71));
        pushButton7->setFont(font);
        pushButton7->setStyleSheet(QStringLiteral("background: white;"));
        pushButton8 = new QPushButton(PinkoodiDialogi);
        pushButton8->setObjectName(QStringLiteral("pushButton8"));
        pushButton8->setGeometry(QRect(920, 470, 81, 71));
        pushButton8->setFont(font);
        pushButton8->setStyleSheet(QStringLiteral("background: white;"));
        pushButton9 = new QPushButton(PinkoodiDialogi);
        pushButton9->setObjectName(QStringLiteral("pushButton9"));
        pushButton9->setGeometry(QRect(1020, 470, 81, 71));
        pushButton9->setFont(font);
        pushButton9->setStyleSheet(QStringLiteral("background: white;"));
        pushButton0 = new QPushButton(PinkoodiDialogi);
        pushButton0->setObjectName(QStringLiteral("pushButton0"));
        pushButton0->setGeometry(QRect(920, 560, 81, 71));
        pushButton0->setFont(font);
        pushButton0->setStyleSheet(QStringLiteral("background: white;"));
        pushButtonDel = new QPushButton(PinkoodiDialogi);
        pushButtonDel->setObjectName(QStringLiteral("pushButtonDel"));
        pushButtonDel->setGeometry(QRect(1020, 560, 81, 71));
        pushButtonDel->setFont(font);
        pushButtonDel->setStyleSheet(QStringLiteral("background: white;"));
        pushButtonLogin = new QPushButton(PinkoodiDialogi);
        pushButtonLogin->setObjectName(QStringLiteral("pushButtonLogin"));
        pushButtonLogin->setGeometry(QRect(820, 560, 81, 71));
        pushButtonLogin->setFont(font);
        pushButtonLogin->setStyleSheet(QStringLiteral("background: white;"));
        lineEditPIN = new QLineEdit(PinkoodiDialogi);
        lineEditPIN->setObjectName(QStringLiteral("lineEditPIN"));
        lineEditPIN->setGeometry(QRect(820, 190, 281, 91));
        QFont font1;
        font1.setPointSize(30);
        font1.setBold(false);
        font1.setUnderline(false);
        font1.setWeight(50);
        lineEditPIN->setFont(font1);
        lineEditPIN->setStyleSheet(QStringLiteral("background: white;"));
        lineEditPIN->setEchoMode(QLineEdit::Password);
        lineEditPIN->setClearButtonEnabled(false);
        labelLogin = new QLabel(PinkoodiDialogi);
        labelLogin->setObjectName(QStringLiteral("labelLogin"));
        labelLogin->setGeometry(QRect(820, 120, 271, 51));
        QFont font2;
        font2.setFamily(QStringLiteral("Roboto"));
        font2.setPointSize(18);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setWeight(9);
        labelLogin->setFont(font2);
        labelLogin->setStyleSheet(QLatin1String("color:red;\n"
"font: 75 18pt \"Roboto\";"));
        pushButtonCancel = new QPushButton(PinkoodiDialogi);
        pushButtonCancel->setObjectName(QStringLiteral("pushButtonCancel"));
        pushButtonCancel->setGeometry(QRect(820, 640, 281, 41));
        pushButtonCancel->setStyleSheet(QStringLiteral("background: white;"));

        retranslateUi(PinkoodiDialogi);

        QMetaObject::connectSlotsByName(PinkoodiDialogi);
    } // setupUi

    void retranslateUi(QDialog *PinkoodiDialogi)
    {
        PinkoodiDialogi->setWindowTitle(QApplication::translate("PinkoodiDialogi", "Dialog", 0));
        pushButton1->setText(QApplication::translate("PinkoodiDialogi", "1", 0));
        pushButton2->setText(QApplication::translate("PinkoodiDialogi", "2", 0));
        pushButton3->setText(QApplication::translate("PinkoodiDialogi", "3", 0));
        pushButton4->setText(QApplication::translate("PinkoodiDialogi", "4", 0));
        pushButton5->setText(QApplication::translate("PinkoodiDialogi", "5", 0));
        pushButton6->setText(QApplication::translate("PinkoodiDialogi", "6", 0));
        pushButton7->setText(QApplication::translate("PinkoodiDialogi", "7", 0));
        pushButton8->setText(QApplication::translate("PinkoodiDialogi", "8", 0));
        pushButton9->setText(QApplication::translate("PinkoodiDialogi", "9", 0));
        pushButton0->setText(QApplication::translate("PinkoodiDialogi", "0", 0));
        pushButtonDel->setText(QApplication::translate("PinkoodiDialogi", "DEL", 0));
        pushButtonLogin->setText(QApplication::translate("PinkoodiDialogi", "LOGIN", 0));
        lineEditPIN->setInputMask(QString());
        lineEditPIN->setPlaceholderText(QApplication::translate("PinkoodiDialogi", "     PINKOODI", 0));
        labelLogin->setText(QString());
        pushButtonCancel->setText(QApplication::translate("PinkoodiDialogi", "CANCEL", 0));
    } // retranslateUi

};

namespace Ui {
    class PinkoodiDialogi: public Ui_PinkoodiDialogi {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PINKOODIDIALOGI_H
