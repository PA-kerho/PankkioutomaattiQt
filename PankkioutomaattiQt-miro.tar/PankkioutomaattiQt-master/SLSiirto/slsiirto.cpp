#include "slsiirto.h"


SLSiirto::SLSiirto()
{
}
