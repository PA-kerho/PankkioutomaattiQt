#ifndef SLSIIRTO_H
#define SLSIIRTO_H
#include "siirtodialog.h"
#include "slsiirto_global.h"

class SLSIIRTOSHARED_EXPORT SLSiirto
{

public:
    SLSiirto();
    SiirtoDialog SiirtoDialogi;
};

#endif // SLSIIRTO_H
